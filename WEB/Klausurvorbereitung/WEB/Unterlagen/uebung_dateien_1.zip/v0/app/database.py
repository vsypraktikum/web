# coding: utf-8

import os
import os.path
import codecs


#----------------------------------------------------------
class Database_cl(object):
#----------------------------------------------------------

   #-------------------------------------------------------
   def __init__(self, pagesDir_spl):
   #-------------------------------------------------------
      self.pagesDir_s = pagesDir_spl
 
   #-------------------------------------------------------
   def getPage_px(self, page_spl):
   #-------------------------------------------------------

      status_b, topic_s, content_s = self.getPageContent_p(page_spl)
      if not status_b:
         # neu anlegen
         self.savePage_px(page_spl, topic_s, content_s)

      return (topic_s, content_s)

   #-------------------------------------------------------
   def savePage_px(self, page_spl, topic_spl, content_spl):
   #-------------------------------------------------------
      status_b = True
      try:
         fp_o = codecs.open(os.path.join(self.pagesDir_s, page_spl), 'w', 'utf-8')
      except:
         status_b = False
      else:
         with fp_o:
            fp_o.write(topic_spl)
            fp_o.write('\n\n')
            fp_o.write(content_spl)
            fp_o.write('\n')
      
      return status_b

   #-------------------------------------------------------
   def getPageContent_p(self, page_spl):
   #-------------------------------------------------------
      topic_s = "-neues Thema-"
      content_s = ""
      status_b = True
      try:
         fp_o = codecs.open(os.path.join(self.pagesDir_s, page_spl), 'r', 'utf-8')
      except:
         status_b = False
      else:
         with fp_o:
            lines_a = fp_o.readlines() #keepends=True)
            if len(lines_a) > 0:
               topic_s = lines_a[0]
            if len(lines_a) > 2:
               data_s = ''
               content_s = data_s.join(lines_a[2:])
      
      return (status_b, topic_s, content_s)

#--------------------------------------
if __name__ == '__main__':
#--------------------------------------
   # Testumgebung
   db_o = Database_cl('../pages')
   topic_s, content_s = db_o.getPage_px('startseite')
   print (topic_s)
   print (content_s)
   db_o.savePage_px('testseite', 'test database.py', 'so testen wir das \nDatabase-Modul')

# EOF