# coding: utf-8

import codecs
import os.path
import string
import re

#----------------------------------------------------------
class View_cl(object):
#----------------------------------------------------------

   #-------------------------------------------------------
   def __init__(self, templateDir_spl):
   #-------------------------------------------------------
      self.templateDir_s = templateDir_spl

   #-------------------------------------------------------
   def getPageViewMode_px(self, base_spl, page_spl, topic_spl, content_spl):
   #-------------------------------------------------------
      status_b, template_s = self.getTemplate_p('pageview.tpl')
      if status_b:
         contentMarkup_s = self.convertContent_p(content_spl, base_spl)
         template_o = string.Template(template_s)
         markup_s = template_o.safe_substitute (base=base_spl, topic=topic_spl, content=contentMarkup_s,page=page_spl)

      return status_b, markup_s
      
   #-------------------------------------------------------
   def getPageEditMode_px(self, base_spl, page_spl, topic_spl, content_spl):
   #-------------------------------------------------------
      status_b, template_s = self.getTemplate_p('pageedit.tpl')
      if status_b:
         template_o = string.Template(template_s)
         markup_s = template_o.safe_substitute (base=base_spl, topic=topic_spl, content=content_spl,page=page_spl)

      return status_b, markup_s
      
   #-------------------------------------------------------
   def getTemplate_p(self, templateName_spl):
   #-------------------------------------------------------
      status_b = True
      content_s = ''
      try:
         fp_o = codecs.open(os.path.join(self.templateDir_s, templateName_spl), 'r', 'utf-8')
      except:
         status_b = False
      else:
         content_s = fp_o.read()

      return (status_b, content_s)

   #-------------------------------------------------------
   def convertContent_p(self, content_spl, base_spl):
   #-------------------------------------------------------
      # Wiki-Verweise (WikiWords) in Links konvertieren
      pattern_s = '([A-Z][a-z]+)+(([A-Z][a-z]+)|[0-9]+)'
      newText_s = '<a href="' + base_spl + '/\g<0>">\g<0></a>'
      newContent_s = re.sub(pattern_s, newText_s, content_spl)

      # Zeilenwechsel durch Einfügen von p-Elementen erhalten
      parts_a = newContent_s.split("\r\n")
      newContent_s = ""
      for part_s in parts_a:
         newContent_s += "<p>" + part_s + "</p>"

      return newContent_s
# EOF
