# coding: utf-8

import cherrypy

from .database import Database_cl
from .view import View_cl

#----------------------------------------------------------
class Application_cl(object):
#----------------------------------------------------------

   #-------------------------------------------------------
   def __init__(self):
   #-------------------------------------------------------
      # spezielle Initialisierung können hier eingetragen werden
      self.db_o = Database_cl('pages')
      self.view_o = View_cl('templates')

   @cherrypy.expose
   #-------------------------------------------------------
   def index(self):
   #-------------------------------------------------------
      # positionale Parameter sind in der Index-Methode (leider) nicht möglich
      # das hat der Entwickler so gewollt

      return self.view('_wiki')

   @cherrypy.expose
   #-------------------------------------------------------
   def view(self, page):
   #-------------------------------------------------------
      # Seite im View-Modus liefern
      topic_s, content_s = self.db_o.getPage_px(page)
      status_b, markup_s = self.view_o.getPageViewMode_px(cherrypy.request.script_name, page, topic_s, content_s)
      if not status_b:
         # Fehler bei Template-Verarbeitung: Meldung auslösen
         raise cherrypy.HTTPError(404, "Fehler bei Template-Verarbeitung")
      return markup_s
   
   @cherrypy.expose
   #-------------------------------------------------------
   def edit(self, page):
   #-------------------------------------------------------
      # angeforderte Seite im Edit-Modus liefern
      topic_s, content_s = self.db_o.getPage_px(page)
      status_b, markup_s = self.view_o.getPageEditMode_px(cherrypy.request.script_name, page, topic_s, content_s)
      if not status_b:
         # Fehler bei Template-Verarbeitung: Meldung auslösen
         raise cherrypy.HTTPError(404, "Fehler bei Template-Verarbeitung")
      return markup_s

   @cherrypy.expose
   #-------------------------------------------------------
   def save(self, page, topic, content):
   #-------------------------------------------------------
      # Seite aktualisieren
      self.db_o.savePage_px(page, topic, content)
      return self.edit(page)

   @cherrypy.expose
   #-------------------------------------------------------
   def delete(self, page):
   #-------------------------------------------------------
      # Seite löschen
      pass

   @cherrypy.expose
   #-------------------------------------------------------
   def default(self, *arguments, **kwargs):
   #-------------------------------------------------------
      # um das Fehlen positionaler Parameter bei der Index-Methode auszugleichen,
      # hier zunächst untersuchen, wie die Anfrage aussieht
      if len(kwargs) == 0 and len(arguments) == 1:
         # ein positionales Argument, als Aufruf einer Seite interpretieren
         return self.view(arguments[0])
      else:
         msg_s = "unbekannte Anforderung: " + \
                 str(arguments) + \
                 ' ' + \
                 str(kwargs)
         raise cherrypy.HTTPError(404, msg_s)
   default.exposed = True
# EOF
