# kennzeichnet ein Verzeichnis als Python-Package

